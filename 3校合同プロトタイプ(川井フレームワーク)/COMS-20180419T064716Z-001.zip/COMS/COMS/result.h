//=============================================================================
//
// ���U���g��ʏ��� [result.h]
// Author : ���ꐶ
//
//=============================================================================
#ifndef _RESULT_H_
#define _RESULT_H_

#include "main.h"

//=============================================================================
// �v���g�^�C�v�錾
void InitResult(int oldMode);
void UninitResult(int mode);
void UpdateResult(void);
void DrawResult(void);

#endif
