//=============================================================================
//
// �^�C�g����ʏ��� [title.h]
// Author : ���ꐶ
//
//=============================================================================
#ifndef _TITLE_H_
#define _TITLE_H_

#include "main.h"

//=============================================================================
// �v���g�^�C�v�錾
void InitTitle(int oldMode);
void UninitTitle(int oldMode);
void UpdateTitle(void);
void DrawTitle(void);

#endif
